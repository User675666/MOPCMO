classdef MOPCMO < ALGORITHM   %参数2最优
 % <multi> <real/integer/label/binary/permutation><constrained>

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            Population1 = Problem.Initialization(); % 一般任务            
            Population2 = Problem.Initialization(); % 约束松弛
            Population3 = Problem.Initialization(); % 无约束
            Fitness1    = Calfitness(Population1.objs,Population1.cons);
            Fitness2   = Calfitness(Population2.objs,Population2.cons);
            Fitness3   = Calfitness(Population3.objs);
            stg=1;
            cnt=0;
            cons = [Population1.cons,Population2.cons,Population3.cons];
            cons(cons<0) = 0;
            VAR0 = max(sum(cons,2));
            if VAR0 == 0
                VAR0 = 1;
            end
            X=0;
            %% Optimization
            n=0;
            while Algorithm.NotTerminated(Population1)
                Q = [];
                cp  = (-log(VAR0)-6)/log(1-0.5);
                VAR = VAR0*(1-X)^cp;
                n=n+1;
                if mod(n,4)==1
                    if stg==1
                        mlp1 = ModelLearning(Population3,Fitness3,64);
                        Offspring1 = DEgenerator(Problem,Population3,mlp1,0.25);
                    else
                        mlp1 = ModelLearning(Population1,Fitness1,64);
                        Offspring1 = DEgenerator(Problem,Population1,mlp1,0.05);
                    end
                else
                    Offspring1=[];
                end
                if stg==1 && Problem.FE<=0.4*Problem.maxFE
                    cnt =cnt +1;
                    std_obj(cnt,:) = std(Population3.objs,[],1);
                    if cnt>100
                        if  sum(std(std_obj(cnt-100:cnt,:),[],1)<0.01) == Problem.M
                                stg = 2;
                        end
                    end
                    MatingPool3 = TournamentSelection(2,Problem.N,Fitness3);
                    Offspring3  = OperatorGAhalf(Problem,Population3(MatingPool3));
                    MatingPool2 = TournamentSelection(2,Problem.N,Fitness2);
                    Offspring2  = OperatorGAhalf(Problem,Population2(MatingPool2));
                    a=X;
                elseif Problem.FE<=(a+0.1)*Problem.maxFE
                    MatingPool1 = TournamentSelection(2,2*Problem.N,Fitness2);
                    Offspring3  = OperatorDE(Problem,Population2,Population2(MatingPool1(1:end/2)),Population2(MatingPool1(end/2+1:end)));
                    MatingPool1 = TournamentSelection(2,2*Problem.N,Fitness3);
                    Offspring2  = OperatorDE(Problem,Population3,Population3(MatingPool1(1:end/2)),Population3(MatingPool1(end/2+1:end)));
                else
                    MatingPool2 = TournamentSelection(2,Problem.N,Fitness2);
                    Offspring2  = OperatorGAhalf(Problem,Population2(MatingPool2));
                    MatingPool4 = TournamentSelection(2,Problem.N,Fitness1);
                    Offspring3  = OperatorGAhalf(Problem,Population1(MatingPool4));    
                end
                X = Problem.FE/Problem.maxFE;
                [Population2,Fitness2] = EnvironmentalSelection2([Population2,Offspring1,Offspring2,Offspring3],Problem.N,VAR);
                [Population3,Fitness3] = EnvironmentalSelection([Population3,Offspring1,Offspring2,Offspring3],Problem.N,false);
                [Population1,Fitness1] = EnvironmentalSelection([Population1,Offspring1,Offspring2,Offspring3],Problem.N,true);
            end
        end
    end
end