function mlp = ModelLearning(Population,Fitness,a)


    %% Prepare the training data
    if length(Population) >= 2
        Rank = randperm(length(Population),floor(length(Population)/2)*2);
    else
        Rank = [1,1]
    end

    Loser  = Rank(1:end/2);
    Winner = Rank(end/2+1:end);            
    Change = Fitness(Loser) <= Fitness(Winner);     
    Temp   = Winner(Change);            
    Winner(Change) = Loser(Change);            
    Loser(Change)  = Temp; 

    LoserDec  = Population(Loser).decs;
    WinnerDec = Population(Winner).decs;
    num_D     = size(LoserDec,2);
    epoch = 20;

    %% Train MLP
    mlp = MMLP(num_D,num_D,1,a,0.5,0.1);
    for i = 1:epoch
        mlp = mlp.train(LoserDec, WinnerDec);


    end 
end

